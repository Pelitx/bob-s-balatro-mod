--- STEAMODDED HEADER
--- MOD_NAME: Bob's Balatro
--- MOD_ID: BOBSBALATRO
--- MOD_AUTHOR: [Pelito]
--- MOD_DESCRIPTION: the 2021 fnf mod but in balatro do you guys remember that mod? it was pretty bad lmaooo who would like that mod 
--- PREFIX: xmpl
----------------------------------------------
------------MOD CODE -------------------------

-- mod icon

if SMODS.Atlas then
    SMODS.Atlas({
        key = "modicon",
        path = "modicon.png",
        px = 32,
        py = 32
    })
end


--bob joker

SMODS.Atlas{
    key = 'bob',
    path = 'bob.png',
    px = 71,
    py = 95
}

SMODS.Joker{
    key = 'bob',
    loc_txt = {
        name = 'Bob',
        text = {
            'Each played {C:red}Heart{} or {C:blue}Club{} card',
            'gives {C:mult}+2{} mult and is',
            '{C:red}destroyed{} after use',
            '{C:attention}The mult stacks.{}'
        }
    },

    atlas = 'bob',
    rarity = 1,
    cost = 5,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,
    pos = {x = 0, y = 0},
    shop_rate = 5,

    config = {
        extra = {
            mult = 2
        }
    },

    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                mult_value = card.ability.extra.mult or 0
            }
        }
    end,

    check_for_unlock = function(self, args)
        if args.type == 'bob_loves_you' then
            unlock_card(self)
        end
        unlock_card(self)
    end,

    calculate = function(self, card, context)
    if card.ability.extra.mult == nil then
        card.ability.extra.mult = 2
    end
-- if this doesn't work ima crash the fuck out dude
    if context.individual and context.cardarea == G.play and context.other_card then
        local suit = context.other_card.base.suit
        if suit == 'Hearts' or suit == 'Clubs' then
            card.ability.extra.mult = card.ability.extra.mult + 2
            SMODS.destroy_cards(context.other_card)
            return {
                message = "+2", -- i could probably think of a clever one but i cannot think of one rn
                colour = G.C.MULT
            }
        end
    end

    if context.joker_main and card.ability.extra.mult > 0 then
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('multhit1', 0.9, 1.1) -- had to use this because the sound broke
                return true
            end
        }))
        return {
            mult_mod = card.ability.extra.mult,
            message = "+" .. tostring(card.ability.extra.mult),
            colour = G.C.MULT
        }
    end
end
}




--ron joker

SMODS.Atlas{
    key = 'ron', --atlas key
    path = 'ron.png', --atlas' path in (yourMod)/assets/1x or (yourMod)/assets/2x
    px = 71, --width of one card
    py = 95 -- height of one card
}
SMODS.Joker{
    key = 'ron', --joker key
    loc_txt = { -- local text
        name = 'Ron',
        text = {
          'When a King is played,',
          'it gives you {X:mult,C:white}X3{} Mult.',
          'If a Queen is played,',
          'it, instead, gives you {X:mult,C:white}X0.5{} Mult.'
        },
        --[[unlock = {
            'Be {C:legendary}cool{}',
        }]]
    },
    atlas = 'ron', --atlas' key
    rarity = 2, --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 10, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = false, --can it be eternal
    perishable_compat = false, --can it be perishable
    pos = {x = 0, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    shop_rate = 7, --rate in shop out of 100
    config = {
        extra = {
            king_xmult = 3.0,
            queen_xmult = 0.5
        }
    },
    loc_vars = function(self,info_queue,card)
        return {
            vars = {
                card.ability.extra.king_xmult,
                card.ability.extra.queen_xmult
            }
        }
    end,

    check_for_unlock = function(self, args)
        if args.type == 'ron_loves_you' then --not a real type, just a joke
            unlock_card(self)
        end
                unlock_card(self) --unlocks the card if it isnt unlocked
    end,
    calculate = function(self,card,context)
        if context.individual and context.cardarea == G.play and
            (context.other_card:get_id() == 13) then
            return {
                Xmult_mod = card.ability.extra.king_xmult,
                message = "Cool!",
                colour = G.C.MULT
            }
        elseif context.individual and context.cardarea == G.play and
            (context.other_card:get_id() == 12) then
            return {
                Xmult_mod = card.ability.extra.queen_xmult,
                message = "ew.",
                colour = G.C.MULT
            }
        end
    end
} 
----------------------------------------------
------------MOD CODE END----------------------