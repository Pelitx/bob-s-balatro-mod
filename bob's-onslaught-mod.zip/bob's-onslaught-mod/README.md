# bob's-onslaught-mod
This mod was coded with hope and dreams and it's duct taped together, sorry if it crashes you need to fix that yourself